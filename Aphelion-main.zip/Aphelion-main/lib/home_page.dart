import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'btrapps/.dart';

final baseUrl = Api.api;

const Color _bgDark       = Color(0xFF0A0E27);
const Color _cardBg       = Color(0xFF111630);
const Color _accentRed    = Color(0xFFF44336);
const Color _darkRed      = Color(0xFFB71C1C);
const Color _softRed      = Color(0xFFEF5350);
const Color _primaryWhite = Color(0xFFFFFFFF);
const Color _softGrey     = Color(0xFF94A3B8);
const Color _glassPrimary = Color(0x1AFFFFFF);
const Color _glassSecond  = Color(0x0DFFFFFF);
const Color _accentGreen  = Color(0xFF4CAF50);
const Color _accentBlue   = Color(0xFF2196F3);

const LinearGradient _redGradient = LinearGradient(
  colors: [_accentRed, _darkRed],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

const LinearGradient _blueGradient = LinearGradient(
  colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

const LinearGradient _greenGradient = LinearGradient(
  colors: [Color(0xFF2E7D32), Color(0xFF1B5E20)],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;

  Set<String> selectedBugIds = {};
  String _selectedBugMode = "number";

  // Sender state
  List<Map<String, dynamic>> _globalSenders  = [];
  List<Map<String, dynamic>> _privateSenders = [];
  Map<String, dynamic>? _selectedGlobalSender;
  Map<String, dynamic>? _selectedPrivateSender;
  bool _isLoadingSenders = false;

  // Channel state
  List<Map<String, dynamic>> _channelList = [];
  Map<String, dynamic>? _selectedChannel;
  bool _isLoadingChannels = false;

  bool _isSending = false;
  String? _responseMessage;

  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _initializeVideoPlayer();
    _fetchSenders();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.0);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((_) => setState(() => _isVideoInitialized = false));
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    if (_isVideoInitialized) {
      _videoController.dispose();
      _chewieController.dispose();
    }
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    return cleaned.length < 8 ? null : cleaned;
  }

  bool isValidGroupLink(String input) =>
      input.contains('chat.whatsapp.com') && input.contains('https://');

  // ── Fetch senders ──────────────────────────────────────────────────────────

  Future<void> _fetchSenders() async {
    setState(() {
      _isLoadingSenders = true;
      _selectedGlobalSender  = null;
      _selectedPrivateSender = null;
    });
    try {
      final key = widget.sessionKey;
      final results = await Future.wait([
        http.get(Uri.parse("$baseUrl/global-senders?key=$key")),
        http.get(Uri.parse("$baseUrl/mySender?key=$key")),
      ]);

      final dataGlobal  = jsonDecode(results[0].body);
      final dataPrivate = jsonDecode(results[1].body);

      setState(() {
        _globalSenders = dataGlobal["valid"] == true && dataGlobal["senders"] != null
            ? List<Map<String, dynamic>>.from(dataGlobal["senders"])
            : [];
        _privateSenders = dataPrivate["valid"] == true && dataPrivate["connections"] != null
            ? List<Map<String, dynamic>>.from(dataPrivate["connections"])
            : [];
      });
    } catch (_) {
      _showAlert("❌ Error", "Gagal memuat daftar sender.");
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  // ── Fetch channels ─────────────────────────────────────────────────────────

  Future<void> _fetchUserChannels() async {
    setState(() { _isLoadingChannels = true; _channelList = []; _selectedChannel = null; });
    try {
      final res  = await http.get(Uri.parse("$baseUrl/mych?key=${widget.sessionKey}"));
      final data = jsonDecode(res.body);
      if (data["valid"] == true && data["sender"] == true && data["channel"] != null) {
        setState(() => _channelList = List<Map<String, dynamic>>.from(data["channel"]));
      } else {
        _showAlert("❌ Gagal", "Tidak dapat mengambil daftar channel.");
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan saat memuat channel.");
    } finally {
      setState(() => _isLoadingChannels = false);
    }
  }

  // ── Send ───────────────────────────────────────────────────────────────────

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key      = widget.sessionKey;

    if (_selectedBugMode == "number") {
      if (formatPhoneNumber(rawInput) == null) {
        _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44).");
        return;
      }
      if (selectedBugIds.isEmpty) {
        _showAlert("❌ No Bug Selected", "Pilih minimal 1 bug untuk dikirim.");
        return;
      }
    } else if (_selectedBugMode == "group") {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Masukkan link group WA yang valid.");
        return;
      }
      if (selectedBugIds.isEmpty) {
        _showAlert("❌ No Bug Selected", "Pilih minimal 1 bug untuk dikirim.");
        return;
      }
    } else if (_selectedBugMode == "channel" && _selectedChannel == null) {
      _showAlert("❌ No Channel", "Pilih channel tujuan terlebih dahulu.");
      return;
    }

    setState(() { _isSending = true; _responseMessage = null; });

    try {
      late http.Response res;
      late Map<String, dynamic> data;

      if (_selectedBugMode == "channel") {
        res  = await http.get(Uri.parse("$baseUrl/raidch?key=$key&id=${_selectedChannel!['id']}"));
        data = jsonDecode(res.body);
      } else if (_selectedBugMode == "group") {
        res  = await http.get(Uri.parse("$baseUrl/raidGroup?key=$key&target=$rawInput"));
        data = jsonDecode(res.body);
      } else {
        final bugsParam   = selectedBugIds.join(',');
        final senderParam = _buildSenderParam();
        res  = await http.get(Uri.parse(
            "$baseUrl/sendBug?key=$key&target=$rawInput&bug=$bugsParam$senderParam"));
        data = jsonDecode(res.body);
      }

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sender"] == false) {
        setState(() => _responseMessage = "❌ Tidak ada sender tersedia.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        final usedType   = data["sender_type"] ?? "auto";
        final usedNumber = data["sender_number"] ?? "-";
        setState(() {
          _responseMessage = "✅ Berhasil dikirim via ${usedType.toString().toUpperCase()} ($usedNumber)!";
          targetController.clear();
          selectedBugIds.clear();
          _selectedChannel = null;
        });
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  String _buildSenderParam() {
    if (_selectedPrivateSender != null) {
      final num = _selectedPrivateSender!['number'] ?? _selectedPrivateSender!['sessionName'] ?? '';
      return "&sender_type=private&sender_number=${Uri.encodeComponent(num)}";
    }
    if (_selectedGlobalSender != null) {
      final num = _selectedGlobalSender!['number'] ?? '';
      return "&sender_type=global&sender_number=${Uri.encodeComponent(num)}";
    }
    return "&sender_type=auto";
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: _accentRed.withOpacity(0.4), width: 1.5),
        ),
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: _accentRed.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.warning_amber_rounded, color: _accentRed, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title,
                style: const TextStyle(color: _accentRed, fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        ]),
        content: Text(msg, style: const TextStyle(color: _softGrey, fontSize: 14, height: 1.5)),
        actions: [
          Container(
            decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(12)),
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK", style: TextStyle(color: _primaryWhite, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  // ── Sender list popup ──────────────────────────────────────────────────────

  void _showSenderListPopup({required bool isGlobal}) {
    final list = isGlobal ? _globalSenders : _privateSenders;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return AlertDialog(
          backgroundColor: _cardBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(
              color: (isGlobal ? _accentBlue : _accentGreen).withOpacity(0.4), width: 1.5),
          ),
          title: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: isGlobal ? _blueGradient : _greenGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                isGlobal ? Icons.public_rounded : Icons.person_rounded,
                color: _primaryWhite, size: 20),
            ),
            const SizedBox(width: 12),
            Text(
              isGlobal ? "GLOBAL SENDER" : "PRIVATE SENDER",
              style: const TextStyle(color: _primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ]),
          content: SizedBox(
            width: double.maxFinite,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
              child: list.isEmpty
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(isGlobal ? Icons.public_off_rounded : Icons.person_off_rounded,
                            color: _softGrey, size: 48),
                        const SizedBox(height: 16),
                        Text(
                          isGlobal ? "Tidak ada global sender" : "Tidak ada private sender",
                          style: const TextStyle(color: _softGrey),
                        ),
                      ],
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final s = list[i];
                        final num = s['number'] ?? s['sessionName'] ?? '';
                        final isOnline = (s['status'] ?? '') == 'online';
                        final currentSel = isGlobal
                            ? (_selectedGlobalSender?['number'] == num)
                            : (_selectedPrivateSender?['number'] == num ||
                               _selectedPrivateSender?['sessionName'] == num);

                        return _senderListTile(
                          number: num,
                          name: s['name'] ?? num,
                          isOnline: isOnline,
                          waType: s['waType'],
                          isGlobal: isGlobal,
                          selected: currentSel,
                          onTap: () => setS(() {
                            if (isGlobal) {
                              _selectedGlobalSender = currentSel ? null : s;
                            } else {
                              _selectedPrivateSender = currentSel ? null : s;
                            }
                          }),
                        );
                      },
                    ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                setS(() {
                  if (isGlobal) {
                    _selectedGlobalSender = null;
                  } else {
                    _selectedPrivateSender = null;
                  }
                });
              },
              child: const Text("RESET", style: TextStyle(color: _softRed)),
            ),
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text("CANCEL", style: TextStyle(color: _softGrey))),
            Container(
              decoration: BoxDecoration(
                gradient: isGlobal ? _blueGradient : _greenGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () {
                  setState(() {});
                  Navigator.pop(ctx);
                },
                child: const Text("OK",
                    style: TextStyle(color: _primaryWhite, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _senderListTile({
    required String number,
    required String name,
    required bool isOnline,
    required bool isGlobal,
    String? waType,
    required bool selected,
    required VoidCallback onTap,
  }) {
    final accent = isGlobal ? _accentBlue : _accentGreen;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: selected ? accent.withOpacity(0.12) : null,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: selected ? accent : _primaryWhite.withOpacity(0.08),
          width: selected ? 1.5 : 1,
        ),
      ),
      child: ListTile(
        leading: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                isGlobal ? Icons.public_rounded : Icons.person_rounded,
                color: accent, size: 20),
            ),
            Positioned(
              bottom: 0, right: 0,
              child: Container(
                width: 10, height: 10,
                decoration: BoxDecoration(
                  color: isOnline ? _accentGreen : _softGrey,
                  shape: BoxShape.circle,
                  border: Border.all(color: _cardBg, width: 1.5),
                ),
              ),
            ),
          ],
        ),
        title: Text(
          name,
          style: TextStyle(
              color: _primaryWhite,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
              fontSize: 14),
        ),
        subtitle: Text(
          "${isOnline ? '🟢 Online' : '🔴 Offline'}"
          "${waType != null && waType != 'Unknown' ? ' • $waType' : ''}"
          " • $number",
          style: const TextStyle(color: _softGrey, fontSize: 11),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: selected
            ? Icon(Icons.check_circle_rounded, color: accent, size: 20)
            : null,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  // ── Channel popup ──────────────────────────────────────────────────────────

  void _showChannelSelectionPopup() {
    if (_channelList.isEmpty) _fetchUserChannels();
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return AlertDialog(
          backgroundColor: _cardBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: _accentRed.withOpacity(0.4), width: 1.5),
          ),
          title: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.campaign_rounded, color: _primaryWhite, size: 20),
            ),
            const SizedBox(width: 12),
            const Text("PILIH CHANNEL",
                style: TextStyle(color: _primaryWhite, fontWeight: FontWeight.bold, fontSize: 16)),
          ]),
          content: SizedBox(
            width: double.maxFinite,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
              child: _isLoadingChannels
                  ? const Center(child: CircularProgressIndicator(color: _accentRed))
                  : _channelList.isEmpty
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.info_outline_rounded, color: _softGrey, size: 48),
                            const SizedBox(height: 16),
                            const Text("Tidak ada channel", style: TextStyle(color: _softGrey)),
                            const SizedBox(height: 16),
                            GestureDetector(
                              onTap: () { Navigator.pop(ctx); _fetchUserChannels(); },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(12)),
                                child: const Text("Refresh", style: TextStyle(color: _primaryWhite, fontWeight: FontWeight.w600)),
                              ),
                            ),
                          ],
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: _channelList.length,
                          itemBuilder: (_, i) {
                            final ch  = _channelList[i];
                            final sel = _selectedChannel?['id'] == ch['id'];
                            return Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              decoration: BoxDecoration(
                                color: sel ? _accentRed.withOpacity(0.12) : null,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: sel ? _accentRed : _primaryWhite.withOpacity(0.08),
                                  width: sel ? 1.5 : 1,
                                ),
                              ),
                              child: ListTile(
                                title: Text(ch['title'] ?? 'Unknown',
                                    style: TextStyle(
                                        color: _primaryWhite,
                                        fontWeight: sel ? FontWeight.bold : FontWeight.normal)),
                                subtitle: Text("ID: ${ch['id']}",
                                    style: const TextStyle(color: _softGrey, fontSize: 11)),
                                trailing: sel
                                    ? const Icon(Icons.check_circle_rounded, color: _accentRed, size: 20)
                                    : null,
                                onTap: () => setS(() => _selectedChannel = ch),
                              ),
                            );
                          },
                        ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx),
                child: const Text("CANCEL", style: TextStyle(color: _softGrey))),
            Container(
              decoration: BoxDecoration(
                gradient: _selectedChannel != null ? _redGradient : null,
                color: _selectedChannel != null ? null : _softGrey.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: _selectedChannel != null
                    ? () {
                        setState(() { targetController.text = _selectedChannel!['title'] ?? ''; });
                        Navigator.pop(ctx);
                      }
                    : null,
                child: Text("OK",
                    style: TextStyle(
                        color: _selectedChannel != null ? _primaryWhite : _softGrey,
                        fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        );
      }),
    );
  }

  // ── Bug selection popup ────────────────────────────────────────────────────

  void _showBugSelectionPopup() {
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return AlertDialog(
          backgroundColor: _cardBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: _accentRed.withOpacity(0.4), width: 1.5),
          ),
          title: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.bug_report_rounded, color: _primaryWhite, size: 20),
            ),
            const SizedBox(width: 12),
            const Text("PILIH BUG",
                style: TextStyle(color: _primaryWhite, fontWeight: FontWeight.bold, fontSize: 16)),
          ]),
          content: SizedBox(
            width: double.maxFinite,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: widget.listBug.length,
                itemBuilder: (_, i) {
                  final bug   = widget.listBug[i];
                  final bugId = bug['bug_id'];
                  final sel   = selectedBugIds.contains(bugId);
                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    decoration: BoxDecoration(
                      color: sel ? _accentRed.withOpacity(0.12) : null,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: sel ? _accentRed : _primaryWhite.withOpacity(0.08),
                        width: sel ? 1.5 : 1,
                      ),
                    ),
                    child: ListTile(
                      leading: Icon(
                        sel ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                        color: sel ? _accentRed : _softGrey, size: 20),
                      title: Text(bug['bug_name'],
                          style: TextStyle(
                              color: _primaryWhite,
                              fontWeight: sel ? FontWeight.bold : FontWeight.normal,
                              fontSize: 14)),
                      subtitle: Text(bug['description'] ?? '',
                          style: const TextStyle(color: _softGrey, fontSize: 11),
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => setS(() {
                        if (sel) { selectedBugIds.remove(bugId); } else { selectedBugIds.add(bugId); }
                      }),
                    ),
                  );
                },
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => setS(() => selectedBugIds.clear()),
                child: const Text("RESET", style: TextStyle(color: _softRed))),
            TextButton(onPressed: () => Navigator.pop(ctx),
                child: const Text("CANCEL", style: TextStyle(color: _softGrey))),
            Container(
              decoration: BoxDecoration(
                gradient: selectedBugIds.isNotEmpty ? _redGradient : null,
                color: selectedBugIds.isEmpty ? _softGrey.withOpacity(0.2) : null,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: selectedBugIds.isNotEmpty ? () => Navigator.pop(ctx) : null,
                child: Text("OK",
                    style: TextStyle(
                        color: selectedBugIds.isNotEmpty ? _primaryWhite : _softGrey,
                        fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        );
      }),
    );
  }

  // ── UI Builders ────────────────────────────────────────────────────────────

  Widget _buildHeaderPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [_glassPrimary, _glassSecond],
            begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _primaryWhite.withOpacity(0.1), width: 1),
        boxShadow: [BoxShadow(color: _accentRed.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Row(children: [
        Container(
          width: 66, height: 66,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: _redGradient,
            boxShadow: [BoxShadow(color: _accentRed.withOpacity(0.45), blurRadius: 16, spreadRadius: 2)],
          ),
          child: ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover)),
        ),
        const SizedBox(width: 18),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ShaderMask(
              shaderCallback: (b) => _redGradient.createShader(Rect.fromLTWH(0, 0, b.width, b.height)),
              child: Text(widget.username,
                  style: const TextStyle(color: _primaryWhite, fontWeight: FontWeight.w900,
                      fontSize: 20, letterSpacing: 0.5)),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_accentRed.withOpacity(0.15), _darkRed.withOpacity(0.1)]),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _accentRed.withOpacity(0.3), width: 1),
              ),
              child: Text(
                "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                style: const TextStyle(color: _softRed, fontSize: 11, fontWeight: FontWeight.bold),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized) {
      return Container(
        height: 200,
        margin: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: _cardBg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _accentRed.withOpacity(0.2)),
        ),
        child: const Center(child: CircularProgressIndicator(color: _accentRed, strokeWidth: 2.5)),
      );
    }
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _accentRed.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: _accentRed.withOpacity(0.3), blurRadius: 24, spreadRadius: 2)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Stack(children: [
            Chewie(controller: _chewieController),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, _darkRed.withOpacity(0.25)],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildModeTab({required String mode, required IconData icon, required String label}) {
    final active = _selectedBugMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() {
          _selectedBugMode = mode;
          targetController.clear();
          if (mode == "channel") selectedBugIds.clear();
          _selectedChannel = null;
        }),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            gradient: active
                ? LinearGradient(colors: [_accentRed.withOpacity(0.2), _darkRed.withOpacity(0.1)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight)
                : null,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: active ? _accentRed : _primaryWhite.withOpacity(0.08),
                width: active ? 1.5 : 1),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: active ? _accentRed : _softGrey, size: 20),
              const SizedBox(height: 6),
              Text(label,
                  style: TextStyle(
                      color: active ? _accentRed : _softGrey,
                      fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 0.5),
                  textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(children: [
      _buildModeTab(mode: "number", icon: Icons.phone_android_rounded, label: "BUG\nNOMOR"),
      const SizedBox(width: 10),
      _buildModeTab(mode: "group",   icon: Icons.group_add_rounded,     label: "BUG\nGROUP"),
      const SizedBox(width: 10),
      _buildModeTab(mode: "channel", icon: Icons.campaign_rounded,       label: "BUG\nCHANNEL"),
    ]);
  }

  // ── Two sender cards ───────────────────────────────────────────────────────

  Widget _buildSenderCards() {
    if (_selectedBugMode == "channel") return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 24),
        // Header row
        Row(children: [
          Container(width: 3, height: 18,
              decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 10),
          const Text("SENDER",
              style: TextStyle(color: _softGrey, fontWeight: FontWeight.w700,
                  fontSize: 12, letterSpacing: 1.5)),
          const Spacer(),
          GestureDetector(
            onTap: _isLoadingSenders ? null : _fetchSenders,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: _glassPrimary, borderRadius: BorderRadius.circular(8)),
              child: _isLoadingSenders
                  ? const SizedBox(width: 14, height: 14,
                      child: CircularProgressIndicator(color: _softGrey, strokeWidth: 1.5))
                  : const Icon(Icons.refresh_rounded, color: _softGrey, size: 16),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        // Two cards side by side
        Row(children: [
          Expanded(child: _buildSenderCard(isGlobal: true)),
          const SizedBox(width: 12),
          Expanded(child: _buildSenderCard(isGlobal: false)),
        ]),
      ],
    );
  }

  Widget _buildSenderCard({required bool isGlobal}) {
    final accent    = isGlobal ? _accentBlue : _accentGreen;
    final gradient  = isGlobal ? _blueGradient : _greenGradient;
    final icon      = isGlobal ? Icons.public_rounded : Icons.person_rounded;
    final label     = isGlobal ? "GLOBAL" : "PRIVATE";
    final list      = isGlobal ? _globalSenders : _privateSenders;
    final selected  = isGlobal ? _selectedGlobalSender : _selectedPrivateSender;
    final onlineCount = list.where((s) => (s['status'] ?? '') == 'online').length;

    final isSelected = selected != null;

    return GestureDetector(
      onTap: () => _showSenderListPopup(isGlobal: isGlobal),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [accent.withOpacity(0.2), accent.withOpacity(0.05)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight)
              : const LinearGradient(colors: [_glassPrimary, _glassSecond],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: isSelected ? accent : _primaryWhite.withOpacity(0.08),
              width: isSelected ? 1.5 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Card header
            Row(children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(gradient: gradient, borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, color: _primaryWhite, size: 16),
              ),
              const SizedBox(width: 8),
              Text(label,
                  style: TextStyle(
                      color: isSelected ? accent : _softGrey,
                      fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)),
              const Spacer(),
              // Online count badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _isLoadingSenders ? "..." : "$onlineCount/${list.length}",
                  style: TextStyle(color: accent, fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            // Selected sender info or placeholder
            if (isSelected) ...[
              Text(
                selected!['name'] ?? selected['number'] ?? '-',
                style: const TextStyle(color: _primaryWhite, fontWeight: FontWeight.bold, fontSize: 13),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Row(children: [
                Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(
                    color: (selected['status'] ?? '') == 'online' ? _accentGreen : _softGrey,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                Text(
                  (selected['status'] ?? '') == 'online' ? 'Online' : 'Offline',
                  style: TextStyle(
                      color: (selected['status'] ?? '') == 'online' ? _accentGreen : _softGrey,
                      fontSize: 11),
                ),
              ]),
            ] else ...[
              Text(
                _isLoadingSenders ? "Memuat..." : (list.isEmpty ? "Tidak ada sender" : "Klik untuk pilih"),
                style: const TextStyle(color: _softGrey, fontSize: 12),
              ),
            ],
            const SizedBox(height: 8),
            // Tap indicator
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(Icons.keyboard_arrow_down_rounded,
                    color: isSelected ? accent : _softGrey, size: 16),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildModeSelector(),
        const SizedBox(height: 28),

        Row(children: [
          Container(width: 3, height: 18,
              decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 10),
          Text(
            _selectedBugMode == "number" ? "NOMOR TARGET"
                : _selectedBugMode == "group" ? "LINK GROUP WA"
                : "PILIH CHANNEL",
            style: const TextStyle(color: _softGrey, fontWeight: FontWeight.w700,
                fontSize: 12, letterSpacing: 1.5),
          ),
        ]),
        const SizedBox(height: 12),

        if (_selectedBugMode == "channel")
          GestureDetector(
            onTap: _showChannelSelectionPopup,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_glassPrimary, _glassSecond],
                    begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _accentRed.withOpacity(0.3), width: 1.5),
              ),
              child: Row(children: [
                Expanded(
                  child: _selectedChannel == null
                      ? const Text("Klik untuk memilih channel",
                          style: TextStyle(color: _softGrey, fontSize: 14))
                      : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(_selectedChannel!['title'] ?? 'Unknown Channel',
                              style: const TextStyle(color: _primaryWhite,
                                  fontWeight: FontWeight.bold, fontSize: 15)),
                          const SizedBox(height: 4),
                          Text("ID: ${_selectedChannel!['id']}",
                              style: const TextStyle(color: _softGrey, fontSize: 11)),
                        ]),
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.keyboard_arrow_down_rounded, color: _primaryWhite, size: 20),
                ),
              ]),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_glassPrimary, _glassSecond],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _primaryWhite.withOpacity(0.1), width: 1),
            ),
            child: TextField(
              controller: targetController,
              style: const TextStyle(color: _primaryWhite, fontSize: 15),
              cursorColor: _accentRed,
              keyboardType: _selectedBugMode == "number"
                  ? TextInputType.phone : TextInputType.url,
              decoration: InputDecoration(
                hintText: _selectedBugMode == "number"
                    ? "Contoh: +62xxxxxxxxxx"
                    : "Contoh: https://chat.whatsapp.com/...",
                hintStyle: TextStyle(color: _softGrey.withOpacity(0.5), fontSize: 13),
                prefixIcon: Container(
                  margin: const EdgeInsets.only(left: 14, right: 10),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(12)),
                  child: Icon(
                    _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link_rounded,
                    color: _primaryWhite, size: 18),
                ),
                prefixIconConstraints: const BoxConstraints(minWidth: 56, minHeight: 48),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18),
                    borderSide: const BorderSide(color: _accentRed, width: 1.5)),
                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
              ),
            ),
          ),

        // Two sender cards
        _buildSenderCards(),

        // Bug selector
        if (_selectedBugMode != "channel") ...[
          const SizedBox(height: 24),
          Row(children: [
            Container(width: 3, height: 18,
                decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            const Text("PILIH BUG",
                style: TextStyle(color: _softGrey, fontWeight: FontWeight.w700,
                    fontSize: 12, letterSpacing: 1.5)),
            const Spacer(),
            if (selectedBugIds.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  gradient: _redGradient, borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: _accentRed.withOpacity(0.3), blurRadius: 6)],
                ),
                child: Text("${selectedBugIds.length} dipilih",
                    style: const TextStyle(color: _primaryWhite, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
          ]),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: _showBugSelectionPopup,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_glassPrimary, _glassSecond],
                    begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _accentRed.withOpacity(0.3), width: 1.5),
              ),
              child: Row(children: [
                Expanded(
                  child: selectedBugIds.isEmpty
                      ? const Text("Klik untuk memilih bug",
                          style: TextStyle(color: _softGrey, fontSize: 14))
                      : Wrap(
                          spacing: 8, runSpacing: 4,
                          children: selectedBugIds.map((bugId) {
                            final bug = widget.listBug.firstWhere(
                                (b) => b['bug_id'] == bugId,
                                orElse: () => {'bug_name': 'Unknown'});
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  _accentRed.withOpacity(0.2), _darkRed.withOpacity(0.1)]),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: _accentRed.withOpacity(0.4)),
                              ),
                              child: Text(bug['bug_name'],
                                  style: const TextStyle(color: _softRed, fontSize: 12,
                                      fontWeight: FontWeight.w600)),
                            );
                          }).toList(),
                        ),
                ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(gradient: _redGradient, borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.keyboard_arrow_down_rounded, color: _primaryWhite, size: 20),
                ),
              ]),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, _) {
        return Container(
          height: 65,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: _redGradient,
            boxShadow: [
              BoxShadow(
                color: _accentRed.withOpacity(0.25 + _pulseController.value * 0.2),
                blurRadius: 16 + _pulseController.value * 16,
                spreadRadius: _pulseController.value * 2,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: _isSending ? null : _sendBug,
              borderRadius: BorderRadius.circular(22),
              child: Center(
                child: _isSending
                    ? const SizedBox(width: 26, height: 26,
                        child: CircularProgressIndicator(color: _primaryWhite, strokeWidth: 2.5))
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.rocket_launch_rounded, color: _primaryWhite, size: 22),
                          SizedBox(width: 12),
                          Text("SEND BUG ATTACK",
                              style: TextStyle(color: _primaryWhite, fontWeight: FontWeight.w900,
                                  fontSize: 17, letterSpacing: 2)),
                        ],
                      ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final isSuccess = _responseMessage!.startsWith('✅');
    final isError   = _responseMessage!.startsWith('❌');
    final Color border = isSuccess ? Colors.greenAccent : isError ? _accentRed : _softRed;
    final Color text   = isSuccess ? Colors.greenAccent : border;
    final IconData icon = isSuccess
        ? Icons.check_circle_outline_rounded
        : isError ? Icons.error_outline_rounded : Icons.info_outline_rounded;
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: border.withOpacity(0.1),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: border.withOpacity(0.5), width: 1),
          boxShadow: [BoxShadow(color: border.withOpacity(0.1), blurRadius: 10)],
        ),
        child: Row(children: [
          Icon(icon, color: text, size: 24),
          const SizedBox(width: 12),
          Expanded(child: Text(_responseMessage!,
              style: TextStyle(color: text, fontWeight: FontWeight.bold, fontSize: 13))),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topLeft, radius: 1.5,
          colors: [_accentRed.withOpacity(0.12), _bgDark, _bgDark],
          stops: const [0.0, 0.4, 1.0],
        ),
      ),
      child: CustomPaint(
        painter: _GridPainter(),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _buildHeaderPanel(),
                _buildVideoPlayer(),
                _buildInputPanel(),
                const SizedBox(height: 36),
                _buildSendButton(),
                _buildResponseMessage(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final thin = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    const grid = 30.0;
    for (double x = 0; x <= size.width; x += grid) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), thin);
    }
    for (double y = 0; y <= size.height; y += grid) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), thin);
    }
    final accent = Paint()
      ..color = const Color(0xFFF44336).withOpacity(0.07)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    for (double x = 0; x <= size.width; x += grid * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), accent);
    }
    for (double y = 0; y <= size.height; y += grid * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), accent);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
